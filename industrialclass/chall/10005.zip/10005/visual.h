/*
 * visual.h — header-only stack-buffer-overflow visualizer framework.
 *
 * Drop this in a challenge directory next to a `main.c` that provides:
 *
 *     void vuln(void);   // the ONLY function containing the overflow
 *     void win(...);     // prints the flag when control is hijacked
 *
 * and a `main()` that just wires up the challenge-specific bits and calls
 * vf_repl().  Everything else (colors, the interactive command loop, the
 * live stack dump, hex/ascii decoding, the safe-restore "preview" mode and
 * the calibration of the buf -> saved-EIP offset) lives here.
 *
 * HOW IT STAYS CORRECT
 *   - The vulnerable frame is entered through vuln(); the framework drives
 *     it via vf_run(), which stages the payload in globals and calls vuln().
 *   - vf_setup() is a *macro* so the __builtin_frame_address/return_address
 *     intrinsics are evaluated in vuln()'s own frame.
 *   - The visualization runs BEFORE the overflow (on a scratch copy), and
 *     the overflow is the last write the frame performs, so no call made
 *     after it can clobber the hijacked saved return address.
 *   - Control flags live in globals, never in vuln()'s stack argument slots
 *     (a >76-byte payload spills past the saved EIP and would otherwise
 *     rewrite them — the classic 32-bit args pitfall).
 *
 * ARCHITECTURE
 *   Word size is taken from sizeof(void*), so the same header renders both
 *   i386 (4-byte words: saved EBP / saved EIP) and x86-64 (8-byte words:
 *   saved RBP / saved RIP) frames.
 *
 * CHALLENGE CONFIG (define BEFORE #include "visual.h"):
 *   VF_LABEL      short name shown in the banner          (default "bof")
 *   VF_TITLE      one-line description                    (default ...)
 *   VF_BUF_SIZE   size of the vulnerable buffer           (default 64)
 *   VF_EXTRA      extra words past saved EIP to display   (default 0)
 *                 (e.g. 3 for fake-ret + two cdecl args on i386)
 *   VF_MAGIC_A/B  optional: expected arg values to check  (i386 args)
 */
#ifndef VISUAL_H
#define VISUAL_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>

/* ------------------------------ config ------------------------------- */
#ifndef VF_BUF_SIZE
#define VF_BUF_SIZE 64
#endif
#ifndef VF_MAX_LEN
#define VF_MAX_LEN  256
#endif
#ifndef VF_SNAP
#define VF_SNAP     384
#endif
#ifndef VF_LINE_MAX
#define VF_LINE_MAX 4096
#endif
#ifndef VF_EXTRA
#define VF_EXTRA    0
#endif
#ifndef VF_LABEL
#define VF_LABEL    "bof"
#endif
#ifndef VF_TITLE
#define VF_TITLE    "interactive stack visualizer"
#endif

/* ------------------------------ colors ------------------------------- */
#define VF_RST  "\033[0m"
#define VF_BOLD "\033[1m"
#define VF_DIM  "\033[2m"
#define VF_GRN  "\033[32m"
#define VF_BGRN "\033[92m"
#define VF_YEL  "\033[33m"
#define VF_BYEL "\033[93m"
#define VF_BRED "\033[91m"
#define VF_BCYN "\033[96m"
#define VF_MAG  "\033[35m"

/* The challenge must provide this (the vulnerable function). */
void vuln(void);

/* ------------------------- framework state --------------------------- */
static const unsigned char *vf_payload;
static size_t               vf_len;
static int                  vf_restore_after;
static int                  vf_verbose;
static int                  vf_extra   = VF_EXTRA;

static uintptr_t            vf_legit_eip;   /* vuln()'s real return addr */
static size_t               vf_eip_off;     /* buf -> saved EIP offset   */
static unsigned char        vf_snapshot[VF_SNAP];

/* Challenge hooks (assigned in main()). */
static void (*vf_banner_hook)(void);
static void (*vf_win_builder)(unsigned char *out, size_t *out_len);

/* Raw frame copy (defined below); integer-typed to dodge object-size warnings. */
static void vf_copy(uintptr_t dst, uintptr_t src, size_t n);

/* ----------------------- stack visualization ------------------------- */

static const char *vf_region_color(size_t off, size_t gap, size_t w, int extra)
{
    if (off < VF_BUF_SIZE)          return VF_GRN;    /* the buffer        */
    if (off < gap)                  return VF_MAG;    /* compiler padding  */
    if (off < gap + w)              return VF_YEL;    /* saved EBP/RBP     */
    if (off < gap + 2 * w)          return VF_BRED;   /* saved EIP/RIP     */
    if (off < gap + 2 * w + (size_t)extra * w) return VF_BCYN; /* ret + args */
    return VF_DIM;                                    /* caller frame      */
}

static const char *vf_region_name(size_t off, size_t gap, size_t w, int extra)
{
    if (off < VF_BUF_SIZE) return "buf";
    if (off < gap)         return "pad";
    if (off < gap + w)     return (w == 8) ? "saved RBP" : "saved EBP";
    if (off < gap + 2 * w) return (w == 8) ? "saved RIP" : "saved EIP";
    if (off < gap + 2 * w + (size_t)extra * w) {
        size_t k = (off - (gap + 2 * w)) / w;
        if (w == 8)        return "ret/arg";
        if (k == 0)        return "fake ret";
        if (k == 1)        return "arg a";
        if (k == 2)        return "arg b";
        return "args";
    }
    return "caller";
}

static void vf_dump(const unsigned char *buf, const unsigned char *fp, int extra)
{
    const size_t w     = sizeof(void *);
    const int    hw    = (int)(w * 2);
    const size_t gap   = (size_t)(fp - buf);
    const size_t total = gap + 2 * w + (size_t)extra * w;
    uintptr_t saved_bp, saved_ip;

    printf("\n" VF_BOLD VF_BCYN "=== LIVE STACK VISUALIZATION ===" VF_RST "\n");
    printf(VF_DIM "   offset  bytes  ascii  region" VF_RST "\n");

    for (size_t off = 0; off < total; off += w) {
        const char *col = vf_region_color(off, gap, w, extra);

        printf(VF_BOLD "%s +%-4zu" VF_RST " ", col, off);
        for (size_t i = 0; i < w; i++) {
            unsigned char b = buf[off + i];
            const char *cc = vf_region_color(off + i, gap, w, extra);
            if (b == 0) printf(VF_DIM "%s%02x " VF_RST, cc, b);
            else        printf(VF_BOLD "%s%02x " VF_RST, cc, b);
        }
        printf(" ");
        for (size_t i = 0; i < w; i++) {
            unsigned char b = buf[off + i];
            const char *cc = vf_region_color(off + i, gap, w, extra);
            char ch = (b >= 32 && b < 127) ? (char)b : '.';
            if (b == 0) printf(VF_DIM "%s%c" VF_RST, cc, ch);
            else        printf("%s%c" VF_RST, cc, ch);
        }
        printf("  %s%s" VF_RST "\n", col, vf_region_name(off, gap, w, extra));
    }

    memcpy(&saved_bp, buf + gap, w);
    memcpy(&saved_ip, buf + gap + w, w);

    printf("\n");
    printf(VF_BOLD "  buf -> saved %s offset = " VF_BYEL "%zu" VF_RST VF_BOLD
           " bytes" VF_RST VF_DIM "  (saved %s at +%zu)" VF_RST "\n",
           (w == 8) ? "RBP" : "EBP", gap, (w == 8) ? "RIP" : "EIP", gap + w);
    printf(VF_BOLD "  saved %s" VF_RST " = " VF_BYEL "0x%0*lx" VF_RST "\n",
           (w == 8) ? "RBP" : "EBP", hw, (unsigned long)saved_bp);
    printf(VF_BOLD "  saved %s" VF_RST " = " VF_BRED "0x%0*lx" VF_RST
           VF_DIM "  (legit: 0x%0*lx)" VF_RST "\n",
           (w == 8) ? "RIP" : "EIP", hw, (unsigned long)saved_ip,
           hw, (unsigned long)vf_legit_eip);

    if (saved_ip != vf_legit_eip)
        printf(VF_BRED VF_BOLD "  !! saved %s OVERWRITTEN -> return will be hijacked" VF_RST "\n",
               (w == 8) ? "RIP" : "EIP");
    else
        printf(VF_BGRN "  saved %s intact" VF_RST "\n", (w == 8) ? "RIP" : "EIP");

#ifdef VF_MAGIC_A
    if (total >= gap + 2 * w + 3 * w) {
        uint32_t a, b;
        memcpy(&a, buf + gap + 2 * w + w, 4);
        memcpy(&b, buf + gap + 2 * w + 2 * w, 4);
        printf(VF_BOLD "  arg a (need " VF_BCYN "0x%08x" VF_RST VF_BOLD ") = %s0x%08x" VF_RST "\n",
               (unsigned)VF_MAGIC_A, a == (uint32_t)VF_MAGIC_A ? VF_BGRN : VF_BRED, (unsigned)a);
        printf(VF_BOLD "  arg b (need " VF_BCYN "0x%08x" VF_RST VF_BOLD ") = %s0x%08x" VF_RST "\n",
               (unsigned)VF_MAGIC_B, b == (uint32_t)VF_MAGIC_B ? VF_BGRN : VF_BRED, (unsigned)b);
    }
#endif

    printf(VF_DIM "  legend: " VF_GRN "buf" VF_RST VF_DIM " | " VF_MAG "pad" VF_RST VF_DIM
           " | " VF_YEL "saved BP" VF_RST VF_DIM " | " VF_BRED "saved IP" VF_RST VF_DIM
           " | " VF_BCYN "ret/args" VF_RST VF_DIM "   (dim = untouched / zero)" VF_RST "\n");
}

/* Render the would-be overflow from a scratch copy (its own frame, so no
 * big local is added to vuln()'s frame).  Call BEFORE the real overflow. */
static void vf_preview(void)
{
    unsigned char view[VF_SNAP];
    size_t gap, vl;

    if (!(vf_verbose && vf_len))
        return;

    gap = vf_eip_off - sizeof(void *);
    vl  = vf_len > VF_SNAP ? VF_SNAP : vf_len;

    memset(view, 0, sizeof(view));
    memcpy(view, vf_payload, vl);
    vf_dump(view, view + gap, vf_extra);
}

/*
 * Copy raw stack bytes through integer-typed pointers.  The snapshot
 * deliberately spans the whole frame (buffer + saved BP/IP + caller), so
 * the compiler's object-size tracking would flag it as an over-read of the
 * 64-byte buffer; the bytes past the buffer are still valid stack memory.
 */
static void vf_copy(uintptr_t dst, uintptr_t src, size_t n)
{
    memcpy((void *)dst, (void *)src, n);
}

/* Undo the overflow (safe "preview" commands only). */
static void vf_restore(void *buf)
{
    if (vf_restore_after)
        vf_copy((uintptr_t)buf, (uintptr_t)vf_snapshot, VF_SNAP);
}

/*
 * Capture the real frame (macro so the intrinsics evaluate in vuln()'s
 * frame), zero the buffer and snapshot the pristine frame for safe mode.
 */
#define VF_SETUP(buf)                                                        \
    do {                                                                     \
        vf_legit_eip = (uintptr_t)__builtin_return_address(0);               \
        vf_eip_off   = (size_t)((unsigned char *)__builtin_frame_address(0)  \
                                - (unsigned char *)(buf)) + sizeof(void *);  \
        memset((buf), 0, VF_BUF_SIZE);                                       \
        vf_copy((uintptr_t)vf_snapshot, (uintptr_t)(buf), VF_SNAP);          \
    } while (0)

/* ------------------------------ helpers ------------------------------ */

static int vf_hexval(int c)
{
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

static size_t vf_decode_hex(const char *s, unsigned char *out, size_t max)
{
    size_t n = 0;
    while (*s && n < max) {
        if (*s == ' ' || *s == '\t') { s++; continue; }
        if (!s[1]) break;
        int hi = vf_hexval(s[0]), lo = vf_hexval(s[1]);
        if (hi < 0 || lo < 0) break;
        out[n++] = (unsigned char)((hi << 4) | lo);
        s += 2;
    }
    return n;
}

/* Stage the payload and enter the vulnerable frame. */
static void vf_run(const unsigned char *payload, size_t len,
                   int restore_after, int verbose, int extra)
{
    vf_payload       = payload;
    vf_len           = len;
    vf_restore_after = restore_after;
    vf_verbose       = verbose;
    vf_extra         = extra;
    vuln();
}

/* ------------------------------- REPL -------------------------------- */

static void vf_usage(void)
{
    printf(VF_BOLD "commands:" VF_RST "\n");
    printf("  " VF_BCYN "ascii:<text>" VF_RST "  payload = the literal text\n");
    printf("  " VF_BCYN "hex:<hex>" VF_RST "     payload = hex bytes\n");
    printf("  " VF_BCYN "run:<hex>" VF_RST "     like hex:, but actually returns "
           "through the frame\n");
    printf("  " VF_BCYN "win" VF_RST "           build & run the ret2win payload\n");
    printf("  " VF_BCYN "stack" VF_RST "         re-dump the current stack\n");
    printf("  " VF_BCYN "help" VF_RST " / " VF_BCYN "quit" VF_RST "\n");
}

static int vf_repl(void)
{
    char line[VF_LINE_MAX];
    unsigned char payload[VF_MAX_LEN];

    setvbuf(stdout, NULL, _IONBF, 0);

    vf_run(NULL, 0, 1, 0, vf_extra);   /* calibrate buf -> saved EIP offset */

    printf(VF_BOLD VF_MAG "\n%s" VF_RST " %s " VF_DIM "(all in C)" VF_RST "\n",
           VF_LABEL, VF_TITLE);
    if (vf_banner_hook)
        vf_banner_hook();
    printf(VF_BOLD "  buffer = " VF_GRN "%d" VF_RST VF_BOLD " bytes, saved %s at "
           VF_BRED "+%zu" VF_RST "\n",
           VF_BUF_SIZE, (sizeof(void *) == 8) ? "RIP" : "EIP", vf_eip_off);
    printf(VF_DIM "  type " VF_RST VF_BCYN "help" VF_RST VF_DIM " for commands" VF_RST "\n\n");

    for (;;) {
        printf(VF_BOLD VF_MAG "payload> " VF_RST);
        if (!fgets(line, sizeof(line), stdin))
            break;

        size_t l = strlen(line);
        while (l && (line[l - 1] == '\n' || line[l - 1] == '\r'))
            line[--l] = '\0';

        if (l == 0) continue;
        if (!strcmp(line, "quit") || !strcmp(line, "exit") || !strcmp(line, ":q"))
            break;
        if (!strcmp(line, "help")) { vf_usage(); continue; }
        if (!strcmp(line, "stack")) { vf_run(NULL, 0, 1, 1, vf_extra); continue; }
        if (!strcmp(line, "win")) {
            if (!vf_win_builder) { printf(VF_BRED "no win payload for this challenge" VF_RST "\n"); continue; }
            size_t n;
            vf_win_builder(payload, &n);
            printf(VF_DIM "  sending ret2win payload (%zu bytes) and executing "
                   "for real..." VF_RST "\n", n);
            vf_run(payload, n, 0, 1, vf_extra);
            continue;
        }
        if (!strncmp(line, "run:", 4)) {
            size_t n = vf_decode_hex(line + 4, payload, VF_MAX_LEN);
            printf(VF_DIM "  %zu bytes, executing for real (no restore)..." VF_RST "\n", n);
            vf_run(payload, n, 0, 1, vf_extra);
            continue;
        }
        if (!strncmp(line, "hex:", 4)) {
            size_t n = vf_decode_hex(line + 4, payload, VF_MAX_LEN);
            vf_run(payload, n, 1, 1, vf_extra);
            continue;
        }
        if (!strncmp(line, "ascii:", 6)) {
            vf_run((const unsigned char *)(line + 6), strlen(line + 6), 1, 1, vf_extra);
            continue;
        }
        vf_run((const unsigned char *)line, strlen(line), 1, 1, vf_extra);
    }

    printf(VF_DIM "bye" VF_RST "\n");
    return 0;
}

#endif /* VISUAL_H */
