/*
 * vuln.c — ch5_64bit: plain 64-bit ret2win, no visualization.
 *
 * main() calls vuln(); vuln() reads into a 64-byte stack buffer with no
 * bounds check.  Redirect the saved return address into win() to print
 * /flag.txt.
 *
 * Build: see Makefile  ->  gcc -fno-stack-protector -no-pie
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

/* Never called by main(): reachable only by hijacking vuln()'s return. */
void win(void)
{
    char flag[128];
    FILE *f = fopen("/flag.txt", "r");

    if (!f) {
        puts("win() reached, but /flag.txt is missing");
        _exit(0);
    }
    if (fgets(flag, sizeof(flag), f)) {
        char *nl = strchr(flag, '\n');
        if (nl)
            *nl = '\0';
        printf("SECRET: %s\n", flag);
    }
    fclose(f);
    _exit(0);
}

/* ------------------------- the vulnerable function ------------------- */
void vuln(void)
{
    char buf[64];              /* <-- 64-byte stack buffer            */

    read(0, buf, 128);         /* <-- NO bounds check => overflow     */
    puts("bye");
}

int main(void)
{
    setvbuf(stdin,  NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);

    puts("bof64 - send your payload");
    vuln();
    return 0;
}
