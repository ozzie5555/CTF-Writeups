/*
 * vuln.c - intentionally vulnerable "echo" service for learning the classic
 *          stack buffer overflow -> ret2win technique.
 *
 * Build (inside Docker, see Dockerfile):
 *   gcc -O0 -g -fno-stack-protector -no-pie -z execstack -o vuln vuln.c
 *
 * Wire protocol (socat wires the TCP socket to stdin/stdout):
 *   client -> server : [4-byte little-endian length][payload bytes]
 *   server -> client : "echo: <payload>\n"
 *
 * THE BUG
 *   echo() reads `len` bytes into a 64-byte stack buffer with no bounds
 *   check.  Any len > 64 smashes the saved RBP and the saved return
 *   address on the stack.
 *
 * THE GOAL
 *   Overwrite the saved return address with the address of win(), which
 *   reads and prints /flag.txt.  win() is never called by main().
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static void read_exact(int fd, void *dst, size_t n)
{
    char *p = dst;
    size_t got = 0;

    while (got < n) {
        ssize_t r = read(fd, p + got, n - got);
        if (r <= 0)
            exit(1);
        got += (size_t)r;
    }
}

/* ------------------------- the vulnerable function ------------------- */
void echo(void)
{
    char buf[64];              /* <-- 64-byte stack buffer            */
    unsigned int len;

    read_exact(0, &len, sizeof(len));
    if (len > 4096)
        exit(1);

    read_exact(0, buf, len);   /* <-- NO bounds check => overflow     */

    printf("echo: %s\n", buf);
}

/* ------------------------- the "win" function ------------------------ */
/* Never called by main(); the only way to run it is to redirect the
 * saved return address of echo() into it. */
void win(void)
{
    char flag[128] = {0};
    FILE *f = fopen("/flag.txt", "r");

    if (!f) {
        printf("win() reached, but /flag.txt is missing\n");
        return;
    }
    if (fgets(flag, sizeof(flag), f)) {
        char *nl = strchr(flag, '\n');
        if (nl)
            *nl = '\0';
        printf("SECRET: %s\n", flag);
    }
    fclose(f);
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    printf("bof-lab echo service\n");
    printf("send: [4-byte LE length][payload]\n");
    echo();
    return 0;
}
